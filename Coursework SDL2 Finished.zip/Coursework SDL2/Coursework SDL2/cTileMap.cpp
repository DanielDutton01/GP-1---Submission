/*
=================
- cTileMap.cpp
- Header file for class definition - IMPLEMENTATION
=================
*/
#include "cTileMap.h"
#include "cGame.h"
#include <string>
#include <vector>
//some variables are implimented and some, the ones using 'extern' are linked to cGame
extern int roundNo;
int i = 0, j=0,k=0,l=0,m=0; //used to detrmine where the 'token' lands on which row of which column
int row[5] = { 4,4,4,4,4 }; //helps identify position on grid
int column[5] = { 0,1,2,3,4 }; //helps identify position on grid
bool isYellow = true; //used to check which colours turn it is
char winnerIs = ' ';
char gameGrid[5][5] = { 0 };
extern bool gameOver;
extern bool placed;
extern int yScore;
extern int rScore;
extern int tScore;
extern bool Rst;

/*
=================================================================
 Defualt Constructor
=================================================================
*/
cTileMap::cTileMap() : cSprite()
{
	this->initialiseMap();
}


void cTileMap::render(SDL_Window* theSDLWND, SDL_Renderer* theRenderer, cTextureMgr* theTxtMgr, vector<LPCSTR> theTxt)
{
	SDL_Rect tilePosXY;
	tilePosXY = { mapStartXY.x,  mapStartXY.y, 0 , 0 };
	// determine number of rows and columns for array
	int numRows = sizeof(tileMap) / sizeof(tileMap[0]);
	int numCols = sizeof(tileMap[0]) / sizeof(tileMap[0][0]);
	int txtToUse = 0;
	for (int row = 0; row < numRows; row++)
	{
		for (int column = 0; column < numCols; column++)
		{
			switch (tileMap[row][column])
			{
			case 1:
				txtToUse = 0;
				break;
			case 2:
				txtToUse = 1;
				break;
			case 3:
				txtToUse = 2;
				break;
			case 4:
				txtToUse = 3;
				break;
			case 5:
				txtToUse = 4;
				break;
			case 6:
				txtToUse = 5;
				break;
			case 7:
				txtToUse = 6;
				break;
			case 8:
				txtToUse = 7;
				break;
			}
			
			aTile.setTexture(theTxtMgr->getTexture(theTxt[txtToUse]));   // txtToUse
			aTile.setSpriteDimensions(theTxtMgr->getTexture(theTxt[txtToUse])->getTWidth(), theTxtMgr->getTexture(theTxt[txtToUse])->getTHeight());
			tilePosXY.w = aTile.getSpritePos().w;
			tilePosXY.h = aTile.getSpritePos().h;
			// Render tile
			aTile.render(theRenderer, &aTile.getSpriteDimensions(), &tilePosXY, aTile.getSpriteRotAngle(), &aTile.getSpriteCentre(), aTile.getSpriteScale());
			tilePosXY.x += aTile.getSpritePos().w;
		}
		tilePosXY.x = mapStartXY.x;
		tilePosXY.y += aTile.getSpritePos().h;
	}

}


/*
=================================================================
Update the sprite position
=================================================================
*/

void cTileMap::update(SDL_Point theMapAreaClicked, int theTokenToPlace)
{
	SDL_Point areaClicked = theMapAreaClicked;
	cout << row[1];
	cout << row[0];
	if (theTokenToPlace > -1)
	{

		//check round number to determine which colour will be used
		if (roundNo % 2 == 0)
		{
			isYellow = false;
		}
		else
		{
			isYellow = true;
		}

		//x area used to determine which column is sellected, y area used to ensure the top row is the only one that accepts drag/drop
		//also positions what has went where on a grid to determine winner later, and increases round counter by 1
		if (areaClicked.x > 100 && areaClicked.x < 164 && areaClicked.y > 100 && areaClicked.y < 164 && i<5) 
		{
			this->tileClickedRC.x = (int)(areaClicked.x - this->mapStartXY.x) / this->aTile.getSpriteDimensions().w;
			this->tileClickedRC.y = (int)((areaClicked.y - this->mapStartXY.y)+322-64*i) / this->aTile.getSpriteDimensions().h;
			//changed x & y around
			this->tileMap[this->tileClickedRC.y][this->tileClickedRC.x] = theTokenToPlace;
			i++;
			if (row[0] > -1)
			{
				if (isYellow) //checks to see if the turn is yellow/red
				{
					gameGrid[row[0]][column[0]] = 'Y'; //places the appropriate symbol
					row[0]--; //changes the row for next time

				}

				if (!isYellow)
				{
					gameGrid[row[0]][column[0]] = 'R';
					row[0]--;
				}
			}
			roundNo++;
			placed = true;		
		}
		if (areaClicked.x > 164 && areaClicked.x < 228 && areaClicked.y > 100 && areaClicked.y < 164 && j < 5)
		{
			this->tileClickedRC.x = (int)(areaClicked.x - this->mapStartXY.x) / this->aTile.getSpriteDimensions().w;
			this->tileClickedRC.y = (int)((areaClicked.y - this->mapStartXY.y) + 322 - 64 * j) / this->aTile.getSpriteDimensions().h;
			//changed x & y around
			this->tileMap[this->tileClickedRC.y][this->tileClickedRC.x] = theTokenToPlace;
			j++;
			if (row[1] > -1)
			{
				if (isYellow)
				{
					gameGrid[row[1]][column[1]] = 'Y';
					row[1]--;

				}

				if (!isYellow)
				{
					gameGrid[row[1]][column[1]] = 'R';
					row[1]--;
				}

			}
			roundNo++;
			placed = true;
		}
		if (areaClicked.x > 228 && areaClicked.x < 292 && areaClicked.y > 100 && areaClicked.y < 164 && k < 5)
		{
			this->tileClickedRC.x = (int)(areaClicked.x - this->mapStartXY.x) / this->aTile.getSpriteDimensions().w;
			this->tileClickedRC.y = (int)((areaClicked.y - this->mapStartXY.y) + 322 - 64 * k) / this->aTile.getSpriteDimensions().h;
			//changed x & y around
			this->tileMap[this->tileClickedRC.y][this->tileClickedRC.x] = theTokenToPlace;
			k++;
			if (row[2] > -1)
			{
				if (isYellow)
				{
					gameGrid[row[2]][column[2]] = 'Y';
					row[2]--;

				}

				if (!isYellow)
				{
					gameGrid[row[2]][column[2]] = 'R';
					row[2]--;
				}
			}
			roundNo++;
			placed = true;
		}
		if (areaClicked.x > 292 && areaClicked.x < 356 && areaClicked.y > 100 && areaClicked.y < 164 && l < 5)
		{
			this->tileClickedRC.x = (int)(areaClicked.x - this->mapStartXY.x) / this->aTile.getSpriteDimensions().w;
			this->tileClickedRC.y = (int)((areaClicked.y - this->mapStartXY.y) + 322 - 64 * l) / this->aTile.getSpriteDimensions().h;
			//changed x & y around
			this->tileMap[this->tileClickedRC.y][this->tileClickedRC.x] = theTokenToPlace;
			l++;
			if (row[3] > -1)
			{
				if (isYellow)
				{
					gameGrid[row[3]][column[3]] = 'Y';
					row[3]--;

				}

				if (!isYellow)
				{
					gameGrid[row[3]][column[3]] = 'R';
					row[3]--;
				}
			}
			roundNo++;
			placed = true;
		}
		if (areaClicked.x > 356 && areaClicked.x < 420 && areaClicked.y > 100 && areaClicked.y < 164 && m < 5)
		{
			this->tileClickedRC.x = (int)(areaClicked.x - this->mapStartXY.x) / this->aTile.getSpriteDimensions().w;
			this->tileClickedRC.y = (int)((areaClicked.y - this->mapStartXY.y) + 322 - 64 * m) / this->aTile.getSpriteDimensions().h;
			//changed x & y around
			this->tileMap[this->tileClickedRC.y][this->tileClickedRC.x] = theTokenToPlace;
			m++;
			if (row[4] > -1)
			{
				if (isYellow)
				{
					gameGrid[row[4]][column[4]] = 'Y';
					row[4]--;

				}

				if (!isYellow)
				{
					gameGrid[row[4]][column[4]] = 'R';
					row[4]--;
				}
			}
			roundNo++;
			placed = true;
		}

		ofstream scoreFile; //used to write score when a win occurs


		//determines win conditions
		//detecting matches in both horizontal/vertical
		for (int n = 0; n < 5; n++)
		{
			if (roundNo <= 26 && gameGrid[n][1] == 'Y' && gameGrid[n][2] == 'Y' && gameGrid[n][3] == 'Y' && (gameGrid[n][0] == 'Y' || gameGrid[n][4] == 'Y')) //if 4 in a row of the 5x5 grid are alligned - win for Y/R player
			{
				winnerIs = 'Y'; //winner of the game is show here
				
				yScore++;		//increases the score variable from whatever it currently is
				scoreFile.open("Data/scores.dat");	//opens the file to be edited
				scoreFile.clear();//clears it so only the three main scores appear in the file
				scoreFile << yScore << " " << rScore << " " << tScore;//assigns the thress scores, this includes the newly changed one. They are sepperated by spaces
				scoreFile.close();//closes the file
				Rst = true;//as the game is over the 'Reset' becomes true so the scores are updated in the textures should the players go back to menu
			}
			if (roundNo <= 26 && gameGrid[n][1] == 'R' && gameGrid[n][2] == 'R' && gameGrid[n][3] == 'R' && (gameGrid[n][0] == 'R' || gameGrid[n][4] == 'R'))
			{
				winnerIs = 'R';
			
				rScore++;
				scoreFile.open("Data/scores.dat");
				scoreFile.clear();
				scoreFile << yScore << " " << rScore << " " << tScore;
				scoreFile.close();
				Rst = true;
			}
			if (roundNo <= 26 && gameGrid[1][n] == 'Y' && gameGrid[2][n] == 'Y' && gameGrid[3][n] == 'Y' && (gameGrid[0][n] == 'Y' || gameGrid[4][n] == 'Y'))
			{
				winnerIs = 'Y';
				
				yScore++;
				scoreFile.open("Data/scores.dat");
				scoreFile.clear();
				scoreFile << yScore << " " << rScore << " " << tScore;
				scoreFile.close();
				Rst = true;
			}
			if (roundNo <= 26 && gameGrid[1][n] == 'R' && gameGrid[2][n] == 'R' && gameGrid[3][n] == 'R' && (gameGrid[0][n] == 'R' || gameGrid[4][n] == 'R'))
			{
				winnerIs = 'R';
				rScore++;
				scoreFile.open("Data/scores.dat");
				scoreFile.clear();
				scoreFile << yScore << " " << rScore << " " << tScore;
				scoreFile.close();
				Rst = true;
			}

		}
		//Detect Matches in Diagonals:
		if (roundNo <= 26 && gameGrid[1][1] == 'Y'&&gameGrid[2][2] == 'Y'&&gameGrid[3][3] == 'Y' && (gameGrid[0][0] == 'Y' || gameGrid[4][4] == 'Y'))
		{
			winnerIs = 'Y';
			
			yScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&gameGrid[1][1] == 'R'&&gameGrid[2][2] == 'R'&&gameGrid[3][3] == 'R' && (gameGrid[0][0] == 'R' || gameGrid[4][4] == 'R'))
		{
			winnerIs = 'R';
			
			rScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&(gameGrid[0][1] == 'Y'&& gameGrid[1][2] == 'Y'&&gameGrid[2][3] == 'Y'&&gameGrid[3][4] == 'Y') || (gameGrid[1][0] == 'Y'&& gameGrid[2][1] == 'Y'&&gameGrid[3][2] == 'Y'&&gameGrid[4][3] == 'Y'))
		{
			winnerIs = 'Y';
			
			yScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&(gameGrid[0][1] == 'R'&& gameGrid[1][2] == 'R'&&gameGrid[2][3] == 'R'&&gameGrid[3][4] == 'R') || (gameGrid[1][0] == 'R'&& gameGrid[2][1] == 'R'&&gameGrid[3][2] == 'R'&&gameGrid[4][3] == 'R'))
		{
			winnerIs = 'R';
			
			rScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&gameGrid[1][3] == 'Y'&&gameGrid[2][2] == 'Y'&&gameGrid[3][1] == 'Y' && (gameGrid[0][4] == 'Y' || gameGrid[4][0] == 'Y'))
		{
			winnerIs = 'Y';
			
			yScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&gameGrid[1][3] == 'R'&&gameGrid[2][2] == 'R'&&gameGrid[3][1] == 'R' && (gameGrid[0][4] == 'R' || gameGrid[4][0] == 'R'))
		{
			winnerIs = 'R';
			
			rScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&(gameGrid[0][3] == 'Y'&& gameGrid[1][2] == 'Y'&&gameGrid[2][1] == 'Y'&&gameGrid[3][0] == 'Y') || (gameGrid[4][1] == 'Y'&& gameGrid[3][2] == 'Y'&&gameGrid[2][3] == 'Y'&&gameGrid[1][4] == 'Y'))
		{
			winnerIs = 'Y';
			
			yScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo <= 26&&(gameGrid[0][3] == 'R'&& gameGrid[1][2] == 'R'&&gameGrid[2][1] == 'R'&&gameGrid[3][0] == 'R') || (gameGrid[4][1] == 'R'&& gameGrid[3][2] == 'R'&&gameGrid[2][3] == 'R'&&gameGrid[1][4] == 'R'))
		{
			winnerIs = 'R';
			
			rScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}
		if (roundNo >= 26)
		{
			winnerIs = 'T';
			
			tScore++;
			scoreFile.open("Data/scores.dat");
			scoreFile.clear();
			scoreFile << yScore << " " << rScore << " " << tScore;
			scoreFile.close();
			Rst = true;
		}

	}
	//detects if someone won the game
	if (winnerIs == 'Y' || winnerIs == 'R' || winnerIs == 'T') 
		//resets variable and tile map so the game may be played again while sending to the end screen via gameOver
	{
		for (int a = 0; a < 5; a++)
		{
			gameGrid[0][a] = ' ';
			gameGrid[1][a] = ' ';
			gameGrid[2][a] = ' ';
			gameGrid[3][a] = ' ';
			gameGrid[4][a] = ' ';
			gameGrid[a][0] = ' ';
			gameGrid[a][1] = ' ';
			gameGrid[a][2] = ' ';
			gameGrid[a][3] = ' ';
			gameGrid[a][4] = ' ';
		}
		initialiseMap();
		roundNo = 1;
		i = 0;
		j = 0;
		k = 0;
		l = 0;
		m = 0;
		winnerIs = ' ';
		row[0] = 4, row[1] = 4, row[2] = 4, row[3] = 4, row[4] = 4, row[5] = 4;
		isYellow = true; 
		gameOver = true;
	}

}

/*
=================================================================
- Set the initial values for the map
=================================================================
*/
void cTileMap::initialiseMap()
{
	/* Let the computer pick a random number */
	random_device rd;    // non-deterministic engine 
	mt19937 gen{ rd() }; // deterministic engine. For most common uses, std::mersenne_twister_engine, fast and high-quality.
	uniform_int_distribution<> dis{ 2, 4 };
	
	for (int row = 0; row < 6; row++)
	{
		for (int column = 0; column < 5; column++)
		{
			if (row == 0 || row == 5)
			{
				tileMap[row][column] = 1;
			}
			else
			{ 
				if (column == 0 || column == 4)
				{
					tileMap[row][column] = 1;
				}
				else
				{
					tileMap[row][column] = dis(gen);
				}
			}
		}
	}
}
/*
=================================================================
- set start position for tile map
=================================================================
*/
void cTileMap::setMapStartXY(SDL_Point startPosXY)
{
	mapStartXY = startPosXY;
}
/*
=================================================================
- get start pposition for tile map
=================================================================
*/
SDL_Point cTileMap::getMapStartXY()
{
	return mapStartXY;
}
