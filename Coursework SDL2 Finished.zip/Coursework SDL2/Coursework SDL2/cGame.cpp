/*
==================================================================================
cGame.cpp
==================================================================================
*/
#include "cGame.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


cGame* cGame::pInstance = NULL;
static cTextureMgr* theTextureMgr = cTextureMgr::getInstance();
static cFontMgr* theFontMgr = cFontMgr::getInstance();
static cSoundMgr* theSoundMgr = cSoundMgr::getInstance();
static cButtonMgr* theButtonMgr = cButtonMgr::getInstance();

// some variables used in this and with a few also used in the tilemap cpp
int dragColour = 4;
int droppedColour = 1;
int roundNo = 1;
bool gameOver;
bool placed = false;
bool newState = false;
int yScore;
int rScore;
int tScore;
bool Rst = false; 

/*
Reads File where the scores for Yellow/Red/Ties are held and assigning them appropriately
*/
int readFile()
{
	ifstream read("Data/scores.dat");
	read >> yScore >> rScore >> tScore;
	return 0;
}

/*
=================================================================================
Constructor
=================================================================================
*/
cGame::cGame()
{
}
/*
=================================================================================
Singleton Design Pattern
=================================================================================
*/
cGame* cGame::getInstance()
{
	if (pInstance == NULL)
	{
		pInstance = new cGame();
	}
	return cGame::pInstance;
}


void cGame::initialise(SDL_Window* theSDLWND, SDL_Renderer* theRenderer)
{
	readFile(); //activates the 'readFile' function to get the scores displayed in-game
	// Get width and height of render context
	SDL_GetRendererOutputSize(theRenderer, &renderWidth, &renderHeight);
	this->m_lastTime = high_resolution_clock::now();
	// Clear the buffer with a black background
	SDL_SetRenderDrawColor(theRenderer, 0, 0, 0, 255);
	SDL_RenderPresent(theRenderer);

	theTextureMgr->setRenderer(theRenderer);
	theFontMgr->initFontLib();
	theSoundMgr->initMixer();

	theAreaClicked = { 0, 0 };

	// Store the textures
	textureName = { "grass", "grassstone", "grassbare", "grassdark", "treedark", "treelight", "treescary", "treeautumn", "theBackground", "transparent", "theBackground", "OpeningScreen", "ClosingScreen", "HScoreScreen" };
	texturesToUse = { "Images\\tile1.png", "Images\\tile2.png", "Images\\tile3.png", "Images\\tile4.png", "Images\\tree1.png", "Images\\tree2.png", "Images\\tree3.png", "Images\\tree4.png", "Images\\theBackground.png", "Images\\transparent.png","Images/Bkg/Bkgnd.png", "Images/Bkg/OpeningScreenF.png", "Images/Bkg/ClosingScreenF.png","Images/Bkg/BkgndHS.png" };
	for (unsigned int tCount = 0; tCount < textureName.size(); tCount++)
	{	
		theTextureMgr->addTexture(textureName[tCount], texturesToUse[tCount]);
	}
	theTileMap.setMapStartXY({ 100, 100 });
	theTokenPicker.setTreeListStartXY({ 472, 100 });

	// Store the textures
	btnNameList = { "exit_btn", "instructions_btn", "load_btn", "menu_btn", "play_btn", "save_btn", "settings_btn", "hs_btn" };
	btnTexturesToUse = { "Images/Buttons/button_exit.png", "Images/Buttons/button_instructions.png", "Images/Buttons/button_load.png", "Images/Buttons/button_menu.png", "Images/Buttons/button_play.png", "Images/Buttons/button_save.png", "Images/Buttons/button_settings.png", "Images/Buttons/button_hscore.png" };
	btnPos = { { 400, 375 }, { 400, 300 }, { 400, 300 }, { 500, 500 }, { 400, 300 }, { 740, 500 }, { 400, 300 }, { 400, 500 } };
	for (unsigned int bCount = 0; bCount < btnNameList.size(); bCount++)
	{
		theTextureMgr->addTexture(btnNameList[bCount], btnTexturesToUse[bCount]);
	}
	for (unsigned int bCount = 0; bCount < btnNameList.size(); bCount++)
	{
		cButton * newBtn = new cButton();
		newBtn->setTexture(theTextureMgr->getTexture(btnNameList[bCount]));
		newBtn->setSpritePos(btnPos[bCount]);
		newBtn->setSpriteDimensions(theTextureMgr->getTexture(btnNameList[bCount])->getTWidth(), theTextureMgr->getTexture(btnNameList[bCount])->getTHeight());
		theButtonMgr->add(btnNameList[bCount], newBtn);
	}
	theGameState = gameState::menu;
	theBtnType = btnTypes::exit;
	// Create textures for Game Dialogue (text)
	fontList = { "pirate", "skeleton", "impact" };
	fontsToUse = { "Fonts/BlackPearl.ttf", "Fonts/SkeletonCloset.ttf", "Fonts/impact.ttf" };
	for (unsigned int fonts = 0; fonts < fontList.size(); fonts++)
	{
		if (fonts == 0)
		{
			theFontMgr->addFont(fontList[fonts], fontsToUse[fonts], 48);
		}
		else
		{
			theFontMgr->addFont(fontList[fonts], fontsToUse[fonts], 36);
		}
	}
	// Create text Textures
	gameTextNames = { "TitleTxt", "CollectTxt", "InstructTxt", "ThanksTxt", "SeeYouTxt", "Wins", "Yellow", "Red", "Ties"};
	gameTextList = { "Connect 4", "Connect 4 tokens to win", "Drag and drop tokens onto the top row", "Thanks for playing!", "See you again soon!","All Prev. Wins: ", "Yellow: ", "Red:", "Ties: " };
	for (unsigned int text = 0; text < gameTextNames.size(); text++)
	{
		if (text == 0 || text == gameTextNames.size() - 1)
		{
			theTextureMgr->addTexture(gameTextNames[text], theFontMgr->getFont("impact")->createTextTexture(theRenderer, gameTextList[text], textType::solid, { 225, 132, 17, 255 }, { 0, 0, 0, 0 }));
		}
		else
		{
			theTextureMgr->addTexture(gameTextNames[text], theFontMgr->getFont("impact")->createTextTexture(theRenderer, gameTextList[text], textType::solid, { 225, 132, 17, 255 }, { 0, 0, 0, 0 }));
		}
	}
	// Load game sounds
	soundList = { "theme", "click", "clank" };
	soundTypes = { soundType::music, soundType::sfx, soundType::sfx };
	soundsToUse = { "Audio/Theme/under-the-stars.mp3", "Audio/SFX/ClickOn.wav", "Audio/SFX/ClankingSound.wav" };
	for (unsigned int sounds = 0; sounds < soundList.size(); sounds++)
	{
		theSoundMgr->add(soundList[sounds], soundsToUse[sounds], soundTypes[sounds]);
	}

	theSoundMgr->getSnd("theme")->play(-1);

	spriteBkgd.setSpritePos({ 0, 0 });
	spriteBkgd.setTexture(theTextureMgr->getTexture("theBackground"));
	spriteBkgd.setSpriteDimensions(theTextureMgr->getTexture("theBackground")->getTWidth(), theTextureMgr->getTexture("theBackground")->getTHeight());

	dragTile.setSpritePos({ 0, 0 });
	dragTile.setTexture(theTextureMgr->getTexture("transparent"));
	dragTile.setSpriteDimensions(theTextureMgr->getTexture("transparent")->getTWidth(), theTextureMgr->getTexture("transparent")->getTHeight());
	//stores textures for the scores
	highScoreTextures = { "score1","score2","score3"};
		string entry = "";
		entry += to_string(yScore);
		theTextureMgr->addTexture(highScoreTextures[0], theFontMgr->getFont("impact")->createTextTexture(theRenderer, entry.c_str(), textType::solid, { 225, 132, 17, 255 }, { 0, 0, 0, 0 }));
		entry = "";
		entry += to_string(rScore);
		theTextureMgr->addTexture(highScoreTextures[1], theFontMgr->getFont("impact")->createTextTexture(theRenderer, entry.c_str(), textType::solid, { 225, 132, 17, 255 }, { 0, 0, 0, 0 }));
		entry = "";
		entry += to_string(tScore);
		theTextureMgr->addTexture(highScoreTextures[2], theFontMgr->getFont("impact")->createTextTexture(theRenderer, entry.c_str(), textType::solid, { 225, 132, 17, 255 }, { 0, 0, 0, 0 }));
	
	gameOver = false;
}

void cGame::run(SDL_Window* theSDLWND, SDL_Renderer* theRenderer)
{
	bool loop = true;

	while (loop)
	{
		//We get the time that passed since the last frame
		double elapsedTime = this->getElapsedSeconds();

		loop = this->getInput(loop);
		this->update(elapsedTime);	

		this->render(theSDLWND, theRenderer);
	}
}

void cGame::render(SDL_Window* theSDLWND, SDL_Renderer* theRenderer)
{

	SDL_RenderClear(theRenderer);
	switch (theGameState)
	{
	case gameState::menu:
	{
		spriteBkgd.setTexture(theTextureMgr->getTexture("OpeningScreen"));
		spriteBkgd.setSpriteDimensions(theTextureMgr->getTexture("OpeningScreen")->getTWidth(), theTextureMgr->getTexture("OpeningScreen")->getTHeight());
		spriteBkgd.render(theRenderer, NULL, NULL, spriteBkgd.getSpriteScale());
		// Render the Title

		tempTextTexture = theTextureMgr->getTexture("TitleTxt");
		pos = { 465, 10, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		scale = { 1, 1 };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("CollectTxt");
		pos = { 355, 100, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("InstructTxt");
		pos = { 285, 175, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		
		//These rendered textures are used as labels to help identify whcih score is which
		tempTextTexture = theTextureMgr->getTexture("Wins");
		pos = { 10, 10 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("Yellow");
		pos = { 10, 60 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("Red");
		pos = { 10, 110 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("Ties");
		pos = { 10, 160 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		//the scores are rendered appropriately
		tempTextTexture = theTextureMgr->getTexture(highScoreTextures[0]);
		pos = { 130, 60 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture(highScoreTextures[1]);
		pos = { 130, 110 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture(highScoreTextures[2]);
		pos = { 130, 160 , tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		//checks if the game is over and needs 'Reset', if so the previous textures were deleted and the initialie function occurs again so new textures will be made
		if (Rst)
		{
			theTextureMgr->deleteTexture(highScoreTextures[0]);
			theTextureMgr->deleteTexture(highScoreTextures[1]);
			theTextureMgr->deleteTexture(highScoreTextures[2]);
			this->initialise(theSDLWND, theRenderer);
			Rst = false;
		}

		// Render Button
		theButtonMgr->getBtn("play_btn")->setSpritePos({ 485, 375 });
		theButtonMgr->getBtn("play_btn")->render(theRenderer, &theButtonMgr->getBtn("play_btn")->getSpriteDimensions(), &theButtonMgr->getBtn("play_btn")->getSpritePos(), theButtonMgr->getBtn("play_btn")->getSpriteScale());
		theButtonMgr->getBtn("exit_btn")->setSpritePos({ 485, 475 });
		theButtonMgr->getBtn("exit_btn")->render(theRenderer, &theButtonMgr->getBtn("exit_btn")->getSpriteDimensions(), &theButtonMgr->getBtn("exit_btn")->getSpritePos(), theButtonMgr->getBtn("exit_btn")->getSpriteScale());
	}
	break;
	case gameState::playing:
	{
		
		spriteBkgd.setTexture(theTextureMgr->getTexture("theBackground"));
		spriteBkgd.setSpriteDimensions(theTextureMgr->getTexture("theBackground")->getTWidth(), theTextureMgr->getTexture("theBackground")->getTHeight());
		spriteBkgd.render(theRenderer, NULL, NULL, spriteBkgd.getSpriteScale());
		tempTextTexture = theTextureMgr->getTexture("TitleTxt");
		pos = { 600, 10, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);


		theButtonMgr->getBtn("exit_btn")->setSpritePos({ 850, 600 });
		theButtonMgr->getBtn("exit_btn")->render(theRenderer, &theButtonMgr->getBtn("exit_btn")->getSpriteDimensions(), &theButtonMgr->getBtn("exit_btn")->getSpritePos(), theButtonMgr->getBtn("exit_btn")->getSpriteScale());
	
		SDL_RenderClear(theRenderer);
		spriteBkgd.render(theRenderer, NULL, NULL, spriteBkgd.getSpriteScale());
		theTileMap.render(theSDLWND, theRenderer, theTextureMgr, textureName);
		theTokenPicker.render(theSDLWND, theRenderer, theTextureMgr, textureName);
		if (theTokenPicker.getTreeToPlant() > -1)
		{
			dragTile.render(theRenderer, &dragTile.getSpriteDimensions(), &dragTile.getSpritePos(), spriteBkgd.getSpriteScale());
		}
		SDL_RenderPresent(theRenderer);
	}
	break;
	case gameState::end:
	{
		spriteBkgd.setTexture(theTextureMgr->getTexture("ClosingScreen"));
		spriteBkgd.setSpriteDimensions(theTextureMgr->getTexture("ClosingScreen")->getTWidth(), theTextureMgr->getTexture("OpeningScreen")->getTHeight());
		spriteBkgd.render(theRenderer, NULL, NULL, spriteBkgd.getSpriteScale());
		tempTextTexture = theTextureMgr->getTexture("TitleTxt");
		pos = { 465, 10, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("ThanksTxt");
		pos = { 400, 100, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		tempTextTexture = theTextureMgr->getTexture("SeeYouTxt");
		pos = { 400, 175, tempTextTexture->getTextureRect().w, tempTextTexture->getTextureRect().h };
		tempTextTexture->renderTexture(theRenderer, tempTextTexture->getTexture(), &tempTextTexture->getTextureRect(), &pos, scale);
		theButtonMgr->getBtn("menu_btn")->setSpritePos({ 485, 300 });
		theButtonMgr->getBtn("menu_btn")->render(theRenderer, &theButtonMgr->getBtn("menu_btn")->getSpriteDimensions(), &theButtonMgr->getBtn("menu_btn")->getSpritePos(), theButtonMgr->getBtn("menu_btn")->getSpriteScale());
		theButtonMgr->getBtn("exit_btn")->setSpritePos({ 485, 350 });
		theButtonMgr->getBtn("exit_btn")->render(theRenderer, &theButtonMgr->getBtn("exit_btn")->getSpriteDimensions(), &theButtonMgr->getBtn("exit_btn")->getSpritePos(), theButtonMgr->getBtn("exit_btn")->getSpriteScale());
	}
	break;
	case gameState::quit:
	{
		loop = false;
		//exits the game
		exit(0);
	}
	break;
	default:
		break;
	}
	SDL_RenderPresent(theRenderer);
}

void cGame::render(SDL_Window* theSDLWND, SDL_Renderer* theRenderer, double rotAngle, SDL_Point* spriteCentre)
{
	SDL_RenderPresent(theRenderer);
}

void cGame::update()
{
	
}

void cGame::update(double deltaTime)
{
	
	// CHeck Button clicked and change state
	if (theGameState == gameState::menu || theGameState == gameState::end)
	{
		theGameState = theButtonMgr->getBtn("exit_btn")->update(theGameState, gameState::quit, theAreaClicked);
	}
	else
	{
		theGameState = theButtonMgr->getBtn("exit_btn")->update(theGameState, gameState::end, theAreaClicked);
	}

	if (theGameState == gameState::menu)
	{
		theGameState = theButtonMgr->getBtn("play_btn")->update(theGameState, gameState::playing, theAreaClicked);

		gameOver = false;

		if (theGameState == gameState::playing && gameOver == false)
		{
			
		}
	}

	theGameState = theButtonMgr->getBtn("menu_btn")->update(theGameState, gameState::menu, theAreaClicked);

	if (theGameState == gameState::playing)
	{
		
		if (gameOver)
		{
			theGameState = gameState::end;
		}
	}


}

bool cGame::getInput(bool theLoop)
{
		SDL_Event event;



		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				theLoop = false;
			}

			switch (event.type)
			{
			case SDL_MOUSEBUTTONDOWN:
				switch (event.button.button)
				{
				case SDL_BUTTON_LEFT:
				{
					theAreaClicked = { event.motion.x, event.motion.y };
					//makes sure appropriate sounds are played when 'Buttons' are clicked
					if (theGameState==gameState::menu &&((theAreaClicked.x > 485 && theAreaClicked.x < 567 && theAreaClicked.y>375 && theAreaClicked.y < 415)||(theAreaClicked.x > 485 && theAreaClicked.x < 561 && theAreaClicked.y>475 && theAreaClicked.y < 515)))
					{
						theSoundMgr->getSnd("click")->play(0);
					}
					if (theGameState == gameState::end && ((theAreaClicked.x > 485 && theAreaClicked.x < 576 && theAreaClicked.y>300 && theAreaClicked.y < 340) || (theAreaClicked.x > 485 && theAreaClicked.x < 561 && theAreaClicked.y>350 && theAreaClicked.y < 390)))
					{
						theSoundMgr->getSnd("click")->play(0);
						
					}

					if (theGameState == gameState::playing)
					{
						//sets colour of dragged token depending on round number
						if (roundNo % 2 == 0)
						{
							dragColour = 5;
						}
						else
						{
							dragColour = 4;
						}


						//get mouse point
						SDL_Point mPoint;
						SDL_GetMouseState(&mPoint.x, &mPoint.y);
						//pick tree via mous position
						theTokenPicker.update(mPoint);

						dragTile.setTexture(theTextureMgr->getTexture(textureName[dragColour + theTokenPicker.getTreeToPlant() % 5]));
					}
				}
				break;
				case SDL_BUTTON_RIGHT:
					break;
				default:
					break;
				}
				break;
			case SDL_MOUSEBUTTONUP:
				switch (event.button.button)
				{
				case SDL_BUTTON_LEFT:
				{

					if (theGameState == gameState::playing)
					{
						//sets colour of droped token depending on round number
						if (roundNo % 2 == 0)
						{
							droppedColour = 1;
						}
						else
						{
							droppedColour = 0;
						}

						//get mouse point
						SDL_Point mPoint;
						SDL_GetMouseState(&mPoint.x, &mPoint.y);

						//place selected token at mouse point
						theTileMap.update(mPoint, theTokenPicker.getTreeToPlant() + droppedColour);

						//prevents no drag/drop
						theTokenPicker.setTreeToPlant(-1);
						dragTile.setTexture(theTextureMgr->getTexture("transparent"));
						

						if (placed)
						{
							theSoundMgr->getSnd("clank")->play(0);
							placed = false;
						}

					}
				}
				break;
				case SDL_BUTTON_RIGHT:
					break;
				default:
					break;
				}
				break;
			case SDL_MOUSEMOTION:
			{
				if (theGameState == gameState::playing)
				{
					SDL_Point mPoint;
					SDL_GetMouseState(&mPoint.x, &mPoint.y);

					dragTile.setSpritePos(mPoint);
				}
			}
			break;
			case SDL_KEYDOWN:
				switch (event.key.keysym.sym)
				{
				case SDLK_ESCAPE:
					theLoop = false;
					break;
				default:
					break;
				}

			default:
				break;
			}

		}
		return theLoop;
}

double cGame::getElapsedSeconds()
{
	this->m_CurrentTime = high_resolution_clock::now();
	this->deltaTime = (this->m_CurrentTime - this->m_lastTime);
	this->m_lastTime = this->m_CurrentTime;
	return deltaTime.count();
}

void cGame::cleanUp(SDL_Window* theSDLWND)
{
	// Delete our OpengL context
	SDL_GL_DeleteContext(theSDLWND);

	// Destroy the window
	SDL_DestroyWindow(theSDLWND);

	// Quit IMG system
	IMG_Quit();

	// Shutdown SDL 2
	SDL_Quit();
}

